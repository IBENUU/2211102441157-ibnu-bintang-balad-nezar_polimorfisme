import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class bee here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class bee extends player
{
    public bee()
    {
        this.setImage(new GreenfootImage("bee.png"));
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()/4;
        int myNewWidth = (int)myImage.getWidth()/4;
        myImage.scale(myNewWidth, myNewHeight);
    
    }
    public void act()
    {
        if(Greenfoot.isKeyDown("w")){
            setLocation(getX(), getY()-4);
            
        }
        if(Greenfoot.isKeyDown("s")){
            setLocation(getX(), getY()+4);
            
        }
        if(Greenfoot.isKeyDown("d")){
            setLocation(getX()+4, getY());
            
        }
        if(Greenfoot.isKeyDown("a")){
            setLocation(getX()-4, getY());
            
        }
    }
}
