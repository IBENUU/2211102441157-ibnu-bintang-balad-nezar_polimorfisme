import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;

public class bird extends player
{
    public bird()
    {
        this.setImage(new GreenfootImage("bird1.png"));
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()/2;
        int myNewWidth = (int)myImage.getWidth()/2;
        myImage.scale(myNewWidth, myNewHeight);
    }
    
    int lastNameNo= 1;
    int animationDelay = 10;
    void animate(){
    if(animationDelay<10){
            animationDelay++;
            return;
    }
    animationDelay = 0;
    if(lastNameNo==3){
        lastNameNo = 1;
    }
    else{        
        lastNameNo++;
    }
    this.setImage(new GreenfootImage("bird"+lastNameNo+".png"));
    GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()/2;
        int myNewWidth = (int)myImage.getWidth()/2;
        myImage.scale(myNewWidth, myNewHeight);
    }
    World wrld;
    public void act()
    {
        animate();
        super.act();
        World wrld = getWorld();
    }
}
