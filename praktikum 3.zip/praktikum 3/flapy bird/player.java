import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class player here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class player extends Actor
{
    int gravity = 2;
    public void act()
    {
        this.setLocation(this.getX(), this.getY()+gravity);
        if (Greenfoot.isKeyDown("space"))
        {
            this.setLocation(this.getX(), this.getY()-8);
        }
        
    }
}
