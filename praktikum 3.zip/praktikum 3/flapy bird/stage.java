import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class stage extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public stage()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1000, 500, 1); 
        prepare();
        Random rnd = new Random();
        for(int i = 0; i<5; i++){
            this.addObject(new cloud(), rnd.nextInt(this.getWidth()-1), rnd.nextInt(this.getHeight()-1));
        }
        
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {   
        bird bird = new bird();
        addObject(bird,176,278);
        bird.setLocation(158,254);

        bee bee = new bee();
        addObject(bee,178,280);
        bee.setLocation(180,300);
        setPaintOrder(player.class);
    }
    
    
}
